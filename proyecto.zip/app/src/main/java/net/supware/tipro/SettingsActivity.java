package net.supware.tipro;

import java.io.File;
import java.util.List;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.widget.Toast;

import net.supware.tipro.model.TIGutsModel;
import net.supware.tipro.view.ProgressCategory;
import net.supware.tipro.view.RomPreference;

public class SettingsActivity extends PreferenceActivity {
	public static final String KEY_ROM_FILENAME = "rom_filename";
	public static final String KEY_FOUND_FILENAMES = "found_filenames";

	private ProgressCategory mRoms;
	private SharedPreferences mPreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		addPreferencesFromResource(R.xml.preferences);

		mRoms = (ProgressCategory) findPreference("roms");

		Preference chooseRom = findPreference("choose_rom");
		chooseRom.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
			@Override
			public boolean onPreferenceClick(Preference preference) {
				openRomPicker();
				return true;
			}
		});
	}

	@Override
	protected void onResume() {
		super.onResume();
		refreshImportedRoms();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode != FindRomsTask.REQUEST_OPEN_ROM || resultCode != RESULT_OK
				|| data == null || data.getData() == null) {
			return;
		}

		Uri uri = data.getData();
		FindRomsTask.persistReadPermission(this, uri);
		mRoms.setProgress(true);
		new ImportSelectedRomTask().execute(uri);
	}

	private void openRomPicker() {
		startActivityForResult(FindRomsTask.createOpenDocumentIntent(),
				FindRomsTask.REQUEST_OPEN_ROM);
	}

	private void refreshImportedRoms() {
		mRoms.setProgress(false);
		mRoms.removeAll();

		List<File> roms = RomStorage.listImportedRoms(this);
		for (File rom : roms) {
			int model = TIGutsModel.getRomFileType(rom);
			if (model == -1) {
				continue;
			}
			addRomPreference(model, rom.getAbsolutePath());
		}
	}

	private void addRomPreference(int model, String filename) {
		int modelResId = 0;
		switch (model) {
		case TIGutsModel.ATI_TI82:
			modelResId = R.string.model_ti82;
			break;
		case TIGutsModel.ATI_TI83:
			modelResId = R.string.model_ti83;
			break;
		case TIGutsModel.ATI_TI83P:
			modelResId = R.string.model_ti83p;
			break;
		case TIGutsModel.ATI_TI83SE:
			modelResId = R.string.model_ti83se;
			break;
		case TIGutsModel.ATI_TI85:
			modelResId = R.string.model_ti85;
			break;
		case TIGutsModel.ATI_TI86:
			modelResId = R.string.model_ti86;
			break;
		}
		if (modelResId == 0) {
			return;
		}
		RomPreference preference = new RomPreference(this, mRoms, modelResId, filename);
		mRoms.addPreference(preference);
	}

	private class ImportSelectedRomTask extends FindRomsTask {
		ImportSelectedRomTask() {
			super(SettingsActivity.this);
		}

		@Override
		public void onFoundModel(int model, String filename) {
			mRoms.setProgress(false);
			setPreference(KEY_ROM_FILENAME, filename);
			setPreference(KEY_FOUND_FILENAMES, filename);
			refreshImportedRoms();
			Toast.makeText(SettingsActivity.this, R.string.toast_rom_imported,
					Toast.LENGTH_SHORT).show();
		}

		@Override
		public void onImportFailed(String message) {
			mRoms.setProgress(false);
			Toast.makeText(SettingsActivity.this, message, Toast.LENGTH_LONG).show();
		}
	}

	public String getPreference(String key, String defaultValue) {
		if (mPreferences == null)
			mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
		return mPreferences.getString(key, defaultValue);
	}

	public void setPreference(String key, String value) {
		if (mPreferences == null)
			mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
		Editor editor = mPreferences.edit();
		editor.putString(key, value);
		editor.commit();
	}
}
