package net.supware.tipro;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.text.TextUtils;

/**
 * Copies a ROM chosen via Storage Access Framework into app-private storage
 * so the native emulator can open it with fopen().
 */
public final class RomStorage {
	private static final int IO_BUFFER_SIZE = 8 * 1024;
	private static final String ROMS_DIR = "roms";

	private RomStorage() {
	}

	public static File getRomsDir(Context context) {
		File dir = new File(context.getFilesDir(), ROMS_DIR);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		return dir;
	}

	public static File importFromUri(Context context, Uri uri) throws IOException {
		String displayName = queryDisplayName(context, uri);
		if (TextUtils.isEmpty(displayName)) {
			displayName = "imported.rom";
		}

		File dest = new File(getRomsDir(context), sanitizeFilename(displayName));
		try (InputStream in = context.getContentResolver().openInputStream(uri);
				OutputStream out = new FileOutputStream(dest)) {
			if (in == null) {
				throw new IOException("Unable to open selected ROM");
			}
			byte[] buffer = new byte[IO_BUFFER_SIZE];
			int read;
			while ((read = in.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}
		}
		return dest;
	}

	public static File ramFileFor(File romFile) {
		String name = romFile.getName();
		int mid = name.lastIndexOf('.');
		String ramName = (mid == -1 ? name : name.substring(0, mid)) + ".RAM";
		return new File(romFile.getParentFile(), ramName);
	}

	public static List<File> listImportedRoms(Context context) {
		File[] files = getRomsDir(context).listFiles();
		if (files == null || files.length == 0) {
			return Collections.emptyList();
		}
		List<File> roms = new ArrayList<>();
		for (File file : files) {
			if (file.isFile() && !file.getName().toUpperCase().endsWith(".RAM")) {
				roms.add(file);
			}
		}
		return roms;
	}

	public static String queryDisplayName(Context context, Uri uri) {
		Cursor cursor = context.getContentResolver().query(uri,
				new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null);
		if (cursor == null) {
			return uri.getLastPathSegment();
		}
		try {
			if (cursor.moveToFirst()) {
				int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
				if (index >= 0) {
					return cursor.getString(index);
				}
			}
		} finally {
			cursor.close();
		}
		return uri.getLastPathSegment();
	}

	private static String sanitizeFilename(String name) {
		String sanitized = name.replaceAll("[^A-Za-z0-9._-]", "_");
		if (TextUtils.isEmpty(sanitized)) {
			return "imported.rom";
		}
		return sanitized;
	}
}
