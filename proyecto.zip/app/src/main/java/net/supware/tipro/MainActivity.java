package net.supware.tipro;

import java.io.File;

import android.content.Intent;
import android.net.Uri;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import net.supware.tipro.model.TIGutsModel;
import net.supware.tipro.model.TISkinModel;

public class MainActivity extends Ti8xActivity {
	private String mRomFilename;
	private boolean mHasPromptedForRom = false;

	@Override
	public Intent getSettingsIntent() {
		return new Intent(this, SettingsActivity.class);
	}

	@Override
	public void onStart() {
		String romFilename = getPreference(SettingsActivity.KEY_ROM_FILENAME, "");

		if (!TextUtils.isEmpty(romFilename) && !(new File(romFilename)).exists()) {
			setPreference(SettingsActivity.KEY_ROM_FILENAME, "");
			File ramFile = RomStorage.ramFileFor(new File(romFilename));
			if (ramFile.exists()) {
				ramFile.delete();
			}
			romFilename = "";
		}

		if (!romFilename.equals(mRomFilename)) {
			mHasPromptedForRom = false;
			mSkinModel = null;
			mGutsModel = null;
			mRomFilename = romFilename;
		}

		super.onStart();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode != FindRomsTask.REQUEST_OPEN_ROM) {
			return;
		}

		if (resultCode != RESULT_OK || data == null || data.getData() == null) {
			showCrouton(Html.fromHtml(getString(R.string.crouton_rom_not_found)),
					getString(R.string.text_tap_to_choose_rom), false);
			enableRomPickerCrouton();
			return;
		}

		Uri uri = data.getData();
		FindRomsTask.persistReadPermission(this, uri);
		showCrouton(getString(R.string.text_loading_rom), null, true);
		new ImportSelectedRomTask().execute(uri);
	}

	@Override
	public TISkinModel getSkinModel() {
		File romFile = new File(mRomFilename == null ? "" : mRomFilename);
		int model = TIGutsModel.getRomFileType(romFile);

		switch (model) {
		case TIGutsModel.ATI_TI82:
			return new TISkinModel(96, 64, R.raw.ti82_480x800,
					R.drawable.ti82_480x800);
		case TIGutsModel.ATI_TI83:
			return new TISkinModel(96, 64, R.raw.ti83_480x800,
					R.drawable.ti83_480x800);
		case TIGutsModel.ATI_TI83P:
			return new TISkinModel(96, 64, R.raw.ti83p_480x800,
					R.drawable.ti83p_480x800);
		case TIGutsModel.ATI_TI85:
			return new TISkinModel(128, 64, R.raw.ti85_480x800,
					R.drawable.ti85_480x800);
		case TIGutsModel.ATI_TI86:
			return new TISkinModel(128, 64, R.raw.ti86_480x800,
					R.drawable.ti86_480x800);
		}

		return new TISkinModel(128, 64, R.raw.ti86_480x800,
				R.drawable.ti86_480x800);
	}

	@Override
	public TIGutsModel getGutsModel() {
		File romFile = new File(mRomFilename == null ? "" : mRomFilename);
		int model = TIGutsModel.getRomFileType(romFile);
		if (model == -1) {
			if (!mHasPromptedForRom) {
				mHasPromptedForRom = true;
				promptForRom();
			}
			return null;
		}

		File ramFile = RomStorage.ramFileFor(romFile);
		return new TIGutsModel(model, ramFile.getAbsolutePath(), mRomFilename);
	}

	private void promptForRom() {
		showCrouton(getString(R.string.text_choose_rom),
				getString(R.string.text_tap_to_choose_rom), false);
		enableRomPickerCrouton();
		openRomPicker();
	}

	private void openRomPicker() {
		startActivityForResult(FindRomsTask.createOpenDocumentIntent(),
				FindRomsTask.REQUEST_OPEN_ROM);
	}

	private void enableRomPickerCrouton() {
		View crouton = findViewById(R.id.crouton);
		crouton.setClickable(true);
		crouton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				openRomPicker();
			}
		});
	}

	private class ImportSelectedRomTask extends FindRomsTask {
		ImportSelectedRomTask() {
			super(MainActivity.this);
		}

		@Override
		public void onFoundModel(int model, String filename) {
			setPreference(SettingsActivity.KEY_ROM_FILENAME, filename);
			setPreference(SettingsActivity.KEY_FOUND_FILENAMES, filename);

			hideCrouton();
			mRomFilename = filename;
			mSkinModel = null;
			mGutsModel = null;
			initSkin();
			startEmulator();
		}

		@Override
		public void onImportFailed(String message) {
			hideCrouton();
			Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
			showCrouton(Html.fromHtml(getString(R.string.crouton_rom_not_found)),
					message, false);
			enableRomPickerCrouton();
		}
	}
}
