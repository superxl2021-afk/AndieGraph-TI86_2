package net.supware.tipro;

import java.io.File;
import java.io.IOException;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;

import net.supware.tipro.model.TIGutsModel;

/**
 * Imports a ROM selected with {@link Intent#ACTION_OPEN_DOCUMENT} into
 * app-private storage and reports the detected calculator model.
 */
abstract public class FindRomsTask extends AsyncTask<Uri, Void, FindRomsTask.RomResult> {

	public static final int REQUEST_OPEN_ROM = 4101;

	private final Context mContext;

	public static class RomResult {
		public final File localFile;
		public final int model;
		public final String errorMessage;

		RomResult(File localFile, int model, String errorMessage) {
			this.localFile = localFile;
			this.model = model;
			this.errorMessage = errorMessage;
		}

		public boolean isSuccess() {
			return localFile != null && model != -1;
		}
	}

	public FindRomsTask(Context context) {
		mContext = context.getApplicationContext();
	}

	public static Intent createOpenDocumentIntent() {
		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
		intent.addCategory(Intent.CATEGORY_OPENABLE);
		intent.setType("*/*");
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
		return intent;
	}

	public static void persistReadPermission(Context context, Uri uri) {
		try {
			context.getContentResolver().takePersistableUriPermission(uri,
					Intent.FLAG_GRANT_READ_URI_PERMISSION);
		} catch (SecurityException ignored) {
			// Some providers do not offer persistable grants; the local copy still works.
		}
	}

	@Override
	protected RomResult doInBackground(Uri... uris) {
		if (uris == null || uris.length == 0 || uris[0] == null) {
			return new RomResult(null, -1, "No ROM was selected.");
		}

		try {
			File localFile = RomStorage.importFromUri(mContext, uris[0]);
			int model = TIGutsModel.getRomFileType(localFile);
			if (model == -1) {
				localFile.delete();
				return new RomResult(null, -1,
						"That file is not a recognized TI-82/83/85/86 ROM.");
			}
			return new RomResult(localFile, model, null);
		} catch (IOException e) {
			return new RomResult(null, -1, e.getMessage());
		}
	}

	@Override
	protected void onPostExecute(RomResult result) {
		if (result != null && result.isSuccess()) {
			onFoundModel(result.model, result.localFile.getAbsolutePath());
		} else {
			onImportFailed(result == null ? "Unable to import ROM." : result.errorMessage);
		}
	}

	public abstract void onFoundModel(int model, String filename);

	public abstract void onImportFailed(String message);
}
