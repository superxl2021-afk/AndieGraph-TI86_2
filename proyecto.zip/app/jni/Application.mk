# Kept for reference only. Gradle now builds the native library with CMake.
APP_ABI := armeabi-v7a arm64-v8a
APP_PLATFORM := android-21
